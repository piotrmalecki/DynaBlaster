java -classpath ./Systeme JavaBomber
